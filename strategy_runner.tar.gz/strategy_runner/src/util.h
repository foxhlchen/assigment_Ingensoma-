#ifndef UTIL_H_
#define UTIL_H_

namespace util {

long TimeCalculation(long curr, long span);

} // namespace util

#endif //UTIL_H_